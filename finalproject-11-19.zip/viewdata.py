from flask import Flask, Blueprint, request, render_template
import json
from collections import OrderedDict
import requests
import time

total_grade = 0
review_count = 0
bp_viewdata = Blueprint('view', __name__, url_prefix='/viewdatas')

def push_data_user(dict): # QR 코드 만들 때 받은 유저 데이터를 넣음
    with open('static/datas/user.json','r') as f:
        user_datas=json.load(f)
    

    user_datas[dict.get("name")]=dict # 원래 거에다가 업데이트 해서 json을 고침
    with open('static/datas/user.json','w',encoding='utf-8') as make_file:
        json.dump(user_datas,make_file,indent='\t')

def push_data_store(qr_data, feel_data): # 유저들의 평가 정보를
    with open('static/datas/store.json','r') as f:
        store_datas=json.load(f)
    
    global total_grade, review_count

    cur_grade=store_datas.get("total_grade") # 새롭게 총점과 리뷰 개수를 갱신
    cur_count=store_datas.get("review_count")
    store_datas["total_grade"]=total_grade=cur_grade+feel_data["grade"]
    store_datas["review_count"]=review_count=cur_count+1

    user_info=json.loads(qr_data.replace("'",'"')) # json 형식에 맞게끔 따옴표를 고침
    user_info.update(feel_data)

    now=time.localtime() # 현재 시각 저장
    user_info["time"]="%04d/%02d/%02d %02d:%02d:%02d"%(now.tm_year,now.tm_mon,now.tm_mday,now.tm_hour,now.tm_min,now.tm_sec)

    store_datas["datas"].append(user_info) # 새롭게 입력받은 유저 정보를 리스트에 추가함

    with open('static/datas/store.json','w',encoding='utf-8') as make_file: # 새 정보 갱신
        json.dump(store_datas,make_file,indent='\t')

def get_logs(): # 현재의 로그를 출력하기 위한 형태로 반환
    with open('static/datas/store.json','r') as f:
        store_datas=json.load(f)

    global total_grade, review_count
    total_grade = store_datas.get("total_grade",0)
    review_count = store_datas.get("review_count",0)
    ave_score=0
    if review_count != 0:
        ave_score=total_grade/review_count

    ret = []
    datas = store_datas.get("datas")
    for items in datas:
        ret.append(items.get("name") + " / " + str(items.get("grade")) + " / " + items.get("time"))
    
    return (ave_score, ret)

@bp_viewdata.route("/") # data들을 그냥 날 것으로 웹에 출력
def view_user_data():
    with open('static/datas/user.json','r') as f:
        user_datas=json.load(f)

    return render_template("viewdatas.html",datas=str(user_datas))