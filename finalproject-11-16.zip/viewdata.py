from flask import Flask, Blueprint, request, render_template
import json
from collections import OrderedDict
import requests
import time

total_grade = 0
review_count = 0
bp_viewdata = Blueprint('view', __name__, url_prefix='/viewdatas')

def push_data_user(dict): # QR 코드 만들 때 받은 유저 데이터를 넣음
    with open('static/datas/user.json','r') as f:
        user_datas=json.load(f)
    

    user_datas[dict.get("name")]=dict
    with open('static/datas/user.json','w',encoding='utf-8') as make_file:
        json.dump(user_datas,make_file,indent='\t')

def push_data_store(qr_data, feel_data):
    with open('static/datas/store.json','r') as f:
        store_datas=json.load(f)
    

    cur_grade=store_datas.get("total_grade")
    cur_count=store_datas.get("review_count")

    global total_grade, review_count


    store_datas["total_grade"]=total_grade=cur_grade+feel_data["grade"]
    store_datas["review_count"]=review_count=cur_count+1
    user_info=json.loads(qr_data.replace("'",'"'))
    user_info.update(feel_data)

    now=time.localtime()
    user_info["time"]="%04d/%02d/%02d %02d:%02d:%02d"%(now.tm_year,now.tm_mon,now.tm_mday,now.tm_hour,now.tm_min,now.tm_sec)

    store_datas["datas"].append(user_info)

    with open('static/datas/store.json','w',encoding='utf-8') as make_file:
        json.dump(store_datas,make_file,indent='\t')

def get_logs():
    with open('static/datas/store.json','r') as f:
        store_datas=json.load(f)

    ret = []
    datas = store_datas.get("datas")
    for items in datas:
        ret.append(items.get("name") + " / " + str(items.get("grade")) + " / " + items.get("time"))
    
    return ret

@bp_viewdata.route("/")
def view_user_data():
    with open('static/datas/user.json','r') as f:
        user_datas=json.load(f)

    return render_template("viewdatas.html",datas=str(user_datas))