from flask import Flask, Blueprint, request, render_template
import json
from collections import OrderedDict
import requests
import viewdata
bp_makeqrdata = Blueprint('makeqr', __name__, url_prefix='/makeqr')

@bp_makeqrdata.route('/',methods=['GET','POST'])
def make_qrcode():
    if(request.method!='GET'):
        return '''error'''
    
    if request.args.get('name') != None:
        name=request.args.get('name')
        gender=request.args.get('gender')
        age=request.args.get('age')
        phone=request.args.get('phone')
        
        file_data={"name":name,"gender":gender,"age":age,"phone":phone}

        format={
            "frame_name":"bottom-frame",
            "qr_code_text": str(file_data),
            "image_format":"JPG",
            "frame_text":"Card",
            "frame_color":"#00D8FF",
            "frame_icon_name": "vcard",
            "frame_text":"Scan me",
            "foreground_color":"#000000",
            "background_color":"#FFFFFF"
        }
        url="https://api.qr-code-generator.com/v1/create?access-token=XbDYEzNXmQ6rrUg9MhJc2A37XS6brnSsKj-TU75Pvh30U7bVTrrLvk5m2oa84uWY"

        res = requests.post(url=url,data=format)
        
        img_path = "static/datas/qr_%s.jpg" % name

        photo = open(img_path, "wb")
        photo.write(res.content)
        photo.close()
        viewdata.push_data_user(file_data)
        return render_template("makeqr.html",image_file="datas/qr_%s.jpg"%name)

    return render_template("makeqr.html")
    


