
relative_path = '/home/pi/src5/finalproject/'
# relative_path = ''
store_path = 'datas.json'
user_path = 'static/datas/user.json'
